-----------------------------------------------------------
-- zs-textui client/main.lua
--
-- exports('Show', text, options) -- options: { icon = string, position = 'right-center' | 'bottom-center' | 'top-center' }
-- exports('Hide')
-- exports('IsShown') -> boolean
-----------------------------------------------------------

local visible = false

local function Show(text, options)
    options = options or {}
    visible = true

    SendNUIMessage({
        action = 'show',
        text = tostring(text or ''),
        icon = options.icon,
        position = options.position or 'right-center'
    })
end

local function Hide()
    if not visible then return end
    visible = false
    SendNUIMessage({ action = 'hide' })
end

exports('Show', Show)
exports('Hide', Hide)
exports('IsShown', function() return visible end)

-- Optional event-based access for resources that prefer events over exports
RegisterNetEvent('zs-textui:show', function(text, options)
    Show(text, options)
end)

RegisterNetEvent('zs-textui:hide', function()
    Hide()
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SendNUIMessage({ action = 'hide' })
end)

-----------------------------------------------------------
-- Test command
-----------------------------------------------------------
RegisterCommand('testtextui', function()
    Show('This is a test text UI', { icon = '💬', position = 'right-center' })
    SetTimeout(5000, function()
        Hide()
    end)
end, false)
