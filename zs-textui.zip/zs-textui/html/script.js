const el = document.getElementById('textui');
const iconEl = document.getElementById('icon');
const textEl = document.getElementById('text');

function show(data) {
    el.classList.remove('hidden', 'right-center', 'bottom-center', 'top-center');
    el.classList.add(data.position || 'right-center');
    textEl.textContent = data.text || '';

    if (data.icon) {
        iconEl.textContent = data.icon;
        iconEl.style.display = 'inline-block';
    } else {
        iconEl.style.display = 'none';
    }
}

function hide() {
    el.classList.add('hidden');
}

window.addEventListener('message', (event) => {
    const d = event.data;
    if (d.action === 'show') show(d);
    else if (d.action === 'hide') hide();
});
