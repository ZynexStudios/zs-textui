# zs-textui

A tiny, fully standalone text UI. No dependencies. Shows a small label on
screen (e.g. "Press [E] to open") and hides it on command.

## Installation

Copy `zs-textui` into `resources/` and add `ensure zs-textui` to your
`server.cfg`.

## Usage

```lua
-- Show
exports['zs-textui']:Show('Press [E] to open the trunk')

-- With an icon (any character/emoji) and position
exports['zs-textui']:Show('Press [E] to open the trunk', {
    icon = '🚗',
    position = 'right-center' -- 'right-center' | 'bottom-center' | 'top-center'
})

-- Hide
exports['zs-textui']:Hide()

-- Check if it's currently visible
local shown = exports['zs-textui']:IsShown()
```

Events are also available if you prefer them over exports:

```lua
TriggerEvent('zs-textui:show', 'Hello there', { position = 'bottom-center' })
TriggerEvent('zs-textui:hide')
```

Both only work client-side (this is a purely local, per-player UI element).

## Test command

Run `/testtextui` in-game to show a sample text UI for 5 seconds.

